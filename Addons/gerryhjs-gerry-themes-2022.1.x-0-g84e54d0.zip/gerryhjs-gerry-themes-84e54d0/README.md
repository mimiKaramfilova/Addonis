Gerry Themes is a refined themes collection designed for comfortable development experience.<br/>

![jb_beam.png](jb_beam.png)

# How to run theme in IDE:
Pick one json file from themes folder, and you can run it in IntelliJ Idea to play themes.
![img.png](img.png)

# Special Thanks:<br/>
*  Kings
*  Beansoft
*  Mallowigi

# Inspired By:<br/>
*  Atom One Dark
*  Material Theme UI Lite for JetBrains