// Game of Key-owns

/**
 * 
 * @param {{ keys: string[], first: object, second: object }} data 
 */
export default function (data) {

  const keys = data.keys;
  const firstObj = data.first;
  const secondObj = data.second;
  const newObj = {};

  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    if (firstObj.hasOwnProperty(key) && secondObj.hasOwnProperty(key)) {
      newObj[key] = [firstObj[key], secondObj[key]];
    } else if (firstObj.hasOwnProperty(key)) {
      newObj[key] = firstObj[key];
    } else if (secondObj.hasOwnProperty(key)) {
      newObj[key] = secondObj[key];
    } else {
      newObj[key] = null;
    }
  }

  return newObj;
}

