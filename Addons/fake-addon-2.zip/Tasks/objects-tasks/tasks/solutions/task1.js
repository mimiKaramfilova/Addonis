// Clone Objects

export default function (data) {
  const cloneObject = {...data}

  for (let property in cloneObject){
    console.log(property)
    if(Array.isArray(cloneObject[property])){
      cloneObject[property] = [...cloneObject[property]]
    } else if (typeof cloneObject[property] === 'object' && cloneObject[property] != null && cloneObject[property] != undefined ){
      cloneObject[property] = {...cloneObject[property]}
    }
  }
  return cloneObject;
}
