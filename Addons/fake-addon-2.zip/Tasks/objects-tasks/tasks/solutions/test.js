let test = {
    keys: ['a', 'b', 'c'],
    first: {
      a: 1,
    },
    second: {
      a: 2,
      b: 3,
    }
  }

  const { first, second, keys } = input;

const newObject = {};

  for (let inKey of keys) {
      newObject[inKey] = null;
  } 

keys.forEach((key) => {

    const firstKey = first[key];
    const secondKey = second[key];

    if (firstKey !== undefined && secondKey !== undefined) {
        newObject[key] = [firstKey, secondKey];
      } else if (firstKey !== undefined) {
        newObject[key] = firstKey;
      } else if (secondKey !== undefined) {
        newObject[key] = secondKey;
      } else {
        newObject[key] = null;
      }
      return newObject;
})









const keysCombined = {}

for (let key1 in firstKey){
    console.log(key1)
    for (let key2 in secondKey){
        console.log(key2)
        if(key1 == key2){
            keysCombined[key1] = [firstKey[key1], secondKey[key2]]
        }else{
            keysCombined[key1] = firstKey[key1];
            keysCombined[key2] = secondKey[key2]
        }
    }
}

console.log(keysCombined)
  

//   for (let aKeys in test[first]) {

//       for (let bKeys in test[second]) {
//           if (aKeys == bKeys && Array.isArray(aKeys) == true && Array.isArray(bKeys == true)) {
//               newObject[aKeys] = test.first[aKeys].concat(test.second[bKeys])
//               console.log(newObject[aKeys])

//           } else if (aKeys == bKeys || Array.isArray(aKeys) == true || Array.isArray(bKeys !== true)) {

//           } else if (aKeys == bKeys || Array.isArray(aKeys) !== true || Array.isArray(bKeys == true)) {

//           } else{
//             newObject[aKeys] = [aKeys, bKeys];
//             console.log( newObject[aKeys] = [aKeys, bKeys])
//           }
          
//       }
//     }
