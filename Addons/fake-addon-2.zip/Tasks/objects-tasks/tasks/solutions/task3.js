// Graduates
/**
 * 
 * @param {{
    course: string;
    minPassingGrade: number;
    students: {
        name: string;
        grades: number[];
    }[];
}} data 
 */
export default function (data) {
  // your code starts here
  const graduatesArr = [];
  let courseTotal = 0; // for courseAverage computation
 
  for (const student of data.students) {
    let sum = 0;
    for (const grade of student.grades){
      sum += grade;
    }
 
    let average = parseFloat((sum / student.grades.length).toFixed(1));
 
    if (average >= data.minPassingGrade) {
      graduatesArr.push({
        name: student.name,
        score: average,
      });
      courseTotal += average;
    }
  }
 
  let courseAverage = graduatesArr.length!==0 ? parseFloat((courseTotal/graduatesArr.length).toFixed(1)) : 0;
 
  return {
    course: data.course,
    minPassingGrade: data.minPassingGrade,
    courseAverage,
    graduates: graduatesArr,
  }
  // your code ends here
}
