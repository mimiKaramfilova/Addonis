(function () {
	const container = document.querySelector("#container");

	getStages().then(stages => {
		container.textContent += stages.join(" ; ");
	});

	container.textContent += "finished! ";

})();

async function getStages() {
	// Simulating delay of fetching from a remote endpoint
	return new Promise(resolve => {
		setTimeout(() => {
			const messages = ["not-started", "in-progress", "ready-for-test"];
			resolve(messages);
		}, 1000); // 1 second delay
	});
}